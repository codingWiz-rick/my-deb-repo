#!/data/data/io.pty/files/usr/bin/sh
exec ./y.sh test "$@"
