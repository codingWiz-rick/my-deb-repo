#ifndef _SHAPESTR_H_
#define _SHAPESTR_H_

#warning "shapestr.h is obsolete and may be removed in the future."
#warning "include <X11/extensions/shapeproto.h> for the protocol defines."
#include <X11/extensions/shapeproto.h>

#endif /* _SHAPESTR_H_ */
