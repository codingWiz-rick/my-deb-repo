#!/data/data/io.pty/files/usr/bin/sh

echo "$@"
