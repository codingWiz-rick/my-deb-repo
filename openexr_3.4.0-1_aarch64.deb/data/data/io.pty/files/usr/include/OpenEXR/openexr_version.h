//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//
// This is the OpenEXR library version information.
// ImfVersion.h contains version information about the file format.
#pragma once
#ifndef INCLUDED_OPENEXR_VERSION_H
#    define INCLUDED_OPENEXR_VERSION_H

#    define OPENEXR_VERSION_MAJOR 3
#    define OPENEXR_VERSION_MINOR 4
#    define OPENEXR_VERSION_PATCH 0

#endif
