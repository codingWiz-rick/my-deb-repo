#ifndef ISL_SET_TYPE_H
#define ISL_SET_TYPE_H

#include <isl/map_type.h>

#endif
