/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef __ASM_GENERIC_SETUP_H
#define __ASM_GENERIC_SETUP_H
#define COMMAND_LINE_SIZE 512
#endif
