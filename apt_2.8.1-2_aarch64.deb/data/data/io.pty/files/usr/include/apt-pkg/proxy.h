// -*- mode: cpp; mode: fold -*-
// Description								/*{{{*/
/* ######################################################################
   
   Proxy - Proxy operations
   
   ##################################################################### */
									/*}}}*/
#ifndef PKGLIB_PROXY_H
#define PKGLIB_PROXY_H

class URI;
APT_PUBLIC bool AutoDetectProxy(URI &URL);


#endif
